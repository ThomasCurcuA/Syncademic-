import { CSSResult } from 'lit';
export declare function injectGlobalCss(css: CSSResult): void;
export declare const editorRowStyles: CSSResult;
