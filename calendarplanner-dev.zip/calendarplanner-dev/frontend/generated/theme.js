import {applyTheme as _applyTheme} from './theme-nova-theme.generated.js';
export const applyTheme = _applyTheme;
